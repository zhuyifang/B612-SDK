# B612-SDK Windows x64 二进制预览包

本包仅包含构建产物、机器可读接口契约和许可声明，不包含 SDK 实现源码、语言绑定、范例、构建脚本或调试符号。

## 文件与环境

- `B612-SDK.dll`：SDK 运行文件，已内嵌 OCR 模型与 ONNX Runtime。
- `B612-SDK.lib`：MSVC 导入库；动态加载 DLL 的调用方无需使用。
- [接口契约](schemas/contract.json)、[错误契约](schemas/error.schema.json)：由本次 DLL 的能力目录生成。
- [构建信息](构建信息.json)：版本、ABI、架构与产物哈希。
- [校验清单](SHA256SUMS.txt)、[第三方声明](THIRD_PARTY_NOTICES.md)、[许可](LICENSE)。

需要 Windows x64、64 位调用进程及 Microsoft Visual C++ x64 运行库。本包为预览版本，尚不构成完整微信版本和桌面环境兼容性承诺。

## 调用约定

通过 C ABI 的 `cdecl` 调用，业务请求与返回使用 UTF-8 JSON。公开导出为 `b612_sdk_abi_version`、`b612_sdk_version`、`b612_sdk_call`、`b612_sdk_cancel`、`b612_sdk_close`、`b612_sdk_buffer_free`。

`b612_sdk_call` 依次接收 uint64 句柄、请求字节指针、size_t 字节数和输出缓冲区指针；返回 int32 状态码。输出结构依次为 data 指针、size_t length、uint64 token，在 x64 下为 24 字节。cancel 与 close 接收 uint64 句柄和输出指针；buffer_free 仅接收输出指针，这三个函数也返回 int32 状态码。abi_version 返回 uint32；version 返回静态 UTF-8 字符串指针。

全局方法使用句柄 `0`；首次接入先调用 `sdk.info`、`sdk.check`。返回缓冲区须交回同一 DLL 的 buffer_free 释放，不能使用调用方内存释放函数。对象句柄仅在当前进程有效，结束后逐个关闭。

contract.json 中每个方法的 input_schema 与 output_schema 是独立的 JSON Schema，分别描述 params 与成功返回的 result。

初始化真实账号可能读取已有缓存，必要时获取本机凭据。发送需要已登录微信、可交互桌面和已完成的窗口校准。环境自检、合成测试通过不代表真实发送已经验证；发送成功状态也不代表对方已接收或已读。未知或部分成功结果仅复核原任务 ID，不自动重发。

OCR 首次使用会在当前用户的私有缓存准备运行库。应用状态、校准和真实账号数据由调用方私有保存，不应提交到公开仓库。

## 分发说明

源码暂不在公开仓库提供。许可证原文与第三方声明随二进制保留；这一分发调整不改变已经授予的许可。再分发请保留相关版权、许可和声明。
