# 第三方来源与许可

本项目为 Rust 实现的 B612-SDK，Cargo 包名为 `b612-sdk`。数据库模块按需只读获取本机凭据，发送模块使用可见桌面输入。参考来源、模型和运行库的许可分别列于下文；模型服务及其网络客户端由调用应用提供。

## 桌面发送流程

- 项目：edgar23333/wechat-auto-sender，MIT。
- 固定版本：`c53e1d7f4a9f4f7f710c00abe5682cdd0a119ed7`，2026-10-01。
- 来源：[固定版本源码](https://github.com/edgar23333/wechat-auto-sender/tree/c53e1d7f4a9f4f7f710c00abe5682cdd0a119ed7)
- 许可原文：[LICENSES/wechat-auto-sender-MIT.txt](LICENSES/wechat-auto-sender-MIT.txt)。
- 参考搜索、界面区域识别与剪贴板输入流程，重新实现为 Rust。使用本地 PP-OCRv6 核对会话标题；输入区采用全选、粘贴和一次配置的发送快捷键。当前实现没有空输入区识别、草稿核验或原文回读。新增窗口/账号绑定、联系人名称冲突检查、持久幂等任务、数据库确认、可配置键鼠空闲等待及发送后焦点恢复。

## 微信 Windows 数据库密钥对象

数据库密钥模块中的 `com.Tencent.WCDB.Config.Cipher` 对象定位规则、对象偏移及 XOR 常量参考：

- 项目：fanyuantaier/wechatauto-replica。
- 固定版本：`62503d76a0db069171cb4e42e87090ad285db489`（原短标识 `62503d7`），2026-10-10。
- 来源：[固定版本的 db.py](https://github.com/fanyuantaier/wechatauto-replica/blob/62503d7/wechatauto/db.py)
- 原项目许可证：Apache-2.0，完整文本见 [LICENSES/Apache-2.0.txt](LICENSES/Apache-2.0.txt)。该固定版本的上游文件树没有单独的 `NOTICE` 文件。
- 本项目修改：改为 Rust 原生只读内存访问、固定大小分块扫描、跨块重叠、逐库页认证；加入静默缓存获取、重试冷却、取消与资源上限。上述来源仅用于数据库取钥规则；取钥模块不写入微信内存、不注入、不发送消息。

## SQLCipher 与 WAL

- SQLCipher 4 页面布局、PBKDF2/HMAC 参数及 Windows 快照行为研究参考 [freanocank/wechat-decrypt](https://github.com/freanocank/wechat-decrypt)（MIT）。许可原文见 [LICENSES/wechat-decrypt-MIT.txt](LICENSES/wechat-decrypt-MIT.txt)，版权署名为 `Copyright (c) 2026 cocofeng`。随包许可文本于 2026-10-17 从提交 `f0b3f9f95dda2d954ee3dbe1d139fb1944a5ecfd` 取得；该标识用于固定许可原文，不追溯宣称早期研究时使用了此提交。
- WAL 格式、generation、滚动校验及提交边界依据 [SQLite 官方 WAL 格式](https://www.sqlite.org/fileformat2.html#wal_file_format)
- macOS Mach 接口及结构常量依据 [Apple XNU 头文件](https://github.com/apple-oss-distributions/xnu/blob/main/osfmk/mach/vm_region.h)

SDK 包附带本声明和 `LICENSES/` 中的许可文本。SDK 自有代码许可证见 `LICENSE`；上述来源材料保留各自声明和许可。

本包仅提供编译产物；Rust 依赖已编入 SDK，依赖版本和原始许可见 [许可证汇总](LICENSES/Rust依赖与运行组件.txt)。SQLite、Zstandard 由各自 Rust 构建依赖从源码编译；交付二进制时应保留依赖包的许可和声明。Windows/macOS 系统 API 通过原生 FFI 调用。

## 原生只读源引擎与文件事件

- SQLCipher 4.6.1 community，由 `libsqlite3-sys 0.35.0` 的 `bundled-sqlcipher-vendored-openssl` 源码构建。采用 BSD 风格许可，原文见 [LICENSES/SQLCipher-BSD.txt](LICENSES/SQLCipher-BSD.txt)。实际源库连接为只读，直接读取主库和 WAL，不创建完整副本。
- OpenSSL 3.6.3，由 `openssl-src 300.6.1+3.6.3` 从源码构建，许可原文见 [LICENSES/OpenSSL-Apache-2.0.txt](LICENSES/OpenSSL-Apache-2.0.txt)。
- notify 8.2.1 提供原生文件事件，许可原文见 [LICENSES/notify-CC0.txt](LICENSES/notify-CC0.txt)。事件只用于唤醒，消费水位及定期补漏负责完整性。

## 本地中文界面识别

- PP-OCRv6 small 检测、识别模型和字符字典由 PaddlePaddle 官方 Hugging Face 仓库取得，固定到具体提交；上游为 PaddleOCR，Apache-2.0，许可见 [LICENSES/PaddleOCR-Apache-2.0.txt](LICENSES/PaddleOCR-Apache-2.0.txt)。完整来源、版本和 SHA-256 见[资源来源清单](models/sources.json)，该清单也随二进制开发包提供。
- 推理通过 `ort` 2.0.0-rc.10 调用 ONNX Runtime 1.23.2 CPU 运行库。源码中的 Windows x64 DLL、Microsoft MIT 许可及第三方声明位于 [运行库许可](LICENSES/LICENSE-ONNXRuntime.txt)。二进制开发包把运行库内嵌到 SDK，并将原文许可和声明放在 `LICENSES/`；使用时准备私有缓存。关闭默认功能的 Rust 接入可按发送接入指南部署运行库到调用方 EXE 同级。识别在本机执行，不依赖 Python，不上传截图。
